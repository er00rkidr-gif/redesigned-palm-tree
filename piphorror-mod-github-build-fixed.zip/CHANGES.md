# Pip AI Horror 1.3.0 – "Pip Experience: Storyline"

## Fixed
* **Arms detaching** – the arm/paw bones used pivots from an old dog skeleton, so every arm animation swung around
  the wrong point. New rig (`geo/friendly_pip.geo.json`) has pivots measured from the OBJ; the paw follows its arm.
* All animations rebuilt for Pip's real body (no legs): idle, walk-hop, listening (arms pop up like ears), peek,
  hunt-pounce, stare, working, plus new `dormant`, `wake_up`, `talk`, `talk_long`.
* Pip spawn egg showed the purple/black "missing model" square – item model added.

## Changed
* The tall white monster is gone. The "fake" Pip is now Pip with **Jerry eyes**: bigger unblinking eyes, tiny pupils,
  head + pupils always turned to the player (and it stares at the nearest player server-side too).
* Friendly Pip's pupils also follow the player, subtly.

## New: Storyline
* **Unknown Corpse** item (Tools tab, `/give @s piphorror:unknown_corpse`, also found in dungeon / mineshaft /
  shipwreck / buried-treasure / temple / stronghold / mansion chests – see `StorylineLoot.java`).
* Right-click a block to set it down: Pip lies motionless with eyes shut.
* Right-click it with a **Bucket of Axolotl**: Pip wakes up, says *"Hey I am pip thanks for feeding me that!"* in a
  friendly high voice, then a few story lines. (`/pip sleep` turns any Pip back into a corpse for testing.)

## New: `/pip gui`
Opens a screen to choose Gemini/OpenAI, paste the API key (masked), model, optional URL, **Save & Test**.
Allowed for ops and the singleplayer owner (no cheats needed). Settings are saved to `config/piphorror-common.toml`.

## Tools (`tools/`)
* `build_pip_rig.py` – regenerates the skeleton + all animations (edit numbers, re-run).
* `preview_rig.py` – renders every animation to `tools/preview/all_animations.png` without launching Minecraft.
* `make_pip_voice.py` – re-renders the voice clips (`BASE_F0` = pitch). Replace the .ogg files with any recording you like.
