package com.piphorror.mod.ai;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.piphorror.mod.config.PipConfig;
import com.piphorror.mod.entity.PipChatListener;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Async HTTP AI client inside the Minecraft mod using Java 17 HttpClient + bundled Gson.
 * Reads the player's API key from config/piphorror-common.toml.
 */
public class PipAiClient {
    private static final HttpClient HTTP = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(10))
        .build();
    private static final Gson GSON = new Gson();
    private static final Deque<String> MEMORY = new ArrayDeque<>();
    private static final Pattern ACTION_TAG = Pattern.compile("\\[ACTION:([A-Z_]+)(?::([^\\]]+))?\\]");
    private static boolean hintedMissingKey = false;

    public static void askPipAsync(ServerLevel level, ServerPlayer player, PipChatListener pip, String message) {
        PipConfig.ensureLoaded();
        String apiKey = PipConfig.getApiKey();

        if (!PipConfig.isAiEnabled() || apiKey.isBlank()) {
            String fallback = buildSmartOfflineReply(player, pip, message);
            player.sendSystemMessage(Component.literal(fallback));
            if (!hintedMissingKey) {
                hintedMissingKey = true;
                player.sendSystemMessage(Component.literal(
                    "§8[Pip Config] §7Add your API key in §econfig/piphorror-common.toml §7or type §e/pip gui §7for full AI chat replies!"
                ));
            }
            return;
        }

        String contextSnapshot = buildWorldContext(level, player, pip);
        CompletableFuture.runAsync(() -> {
            try {
                String rawReply = callConfiguredApi(apiKey, contextSnapshot, player.getName().getString(), message);
                if (rawReply == null || rawReply.isBlank()) {
                    return;
                }
                level.getServer().execute(() -> handleAiResponse(level, player, pip, message, rawReply.trim()));
            } catch (Exception ex) {
                level.getServer().execute(() ->
                    player.sendSystemMessage(Component.literal("§8[Pip AI] §cAPI request failed: " + ex.getMessage()))
                );
            }
        });
    }

    private static String callConfiguredApi(String apiKey, String worldContext, String playerName, String message) throws Exception {
        String provider = PipConfig.getProvider().toLowerCase(Locale.ROOT);
        boolean useGemini = provider.contains("gemini") || (!provider.contains("openai") && apiKey.startsWith("AIza"));
        String model = PipConfig.getModel().isBlank() ? (useGemini ? "gemini-2.5-flash" : "gpt-4o-mini") : PipConfig.getModel();

        String sysPrompt = PipConfig.getSystemPrompt() + "\n"
            + "World context: " + worldContext + "\n"
            + "Recent chat: " + String.join(" | ", MEMORY) + "\n"
            + "If the player wants you to act, append ONE optional tag at the very end: "
            + "[ACTION:GATHER_WOOD], [ACTION:FETCH:<item_name>], [ACTION:KILL:<mob_or_player>], [ACTION:STALK_PEEK], or [ACTION:FOLLOW].";

        if (useGemini) {
            String base = PipConfig.getBaseUrl().isBlank()
                ? "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent?key=" + apiKey
                : PipConfig.getBaseUrl();

            JsonObject sysPart = new JsonObject();
            sysPart.addProperty("text", sysPrompt);
            JsonObject sysInst = new JsonObject();
            JsonArray sysParts = new JsonArray();
            sysParts.add(sysPart);
            sysInst.add("parts", sysParts);

            JsonObject userPart = new JsonObject();
            userPart.addProperty("text", playerName + ": " + message);
            JsonObject userMsg = new JsonObject();
            userMsg.addProperty("role", "user");
            JsonArray userParts = new JsonArray();
            userParts.add(userPart);
            userMsg.add("parts", userParts);

            JsonArray contents = new JsonArray();
            contents.add(userMsg);

            JsonObject genCfg = new JsonObject();
            genCfg.addProperty("maxOutputTokens", PipConfig.getMaxTokens());
            if (model.contains("2.5-flash")) {
                // Gemini 2.5 Flash "thinks" first and can use up the whole token budget, leaving an empty reply.
                JsonObject thinking = new JsonObject();
                thinking.addProperty("thinkingBudget", 0);
                genCfg.add("thinkingConfig", thinking);
            }
            genCfg.addProperty("temperature", 0.8);

            JsonObject payload = new JsonObject();
            payload.add("systemInstruction", sysInst);
            payload.add("contents", contents);
            payload.add("generationConfig", genCfg);

            HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(base))
                .timeout(Duration.ofSeconds(18))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(payload)))
                .build();

            HttpResponse<String> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() >= 400) {
                throw new IllegalStateException(describeHttpError(resp.statusCode(), resp.body()));
            }
            JsonObject json = JsonParser.parseString(resp.body()).getAsJsonObject();
            JsonArray candidates = json.getAsJsonArray("candidates");
            if (candidates != null && candidates.size() > 0) {
                JsonObject c0 = candidates.get(0).getAsJsonObject();
                JsonArray parts = c0.getAsJsonObject("content").getAsJsonArray("parts");
                if (parts != null && parts.size() > 0) {
                    return parts.get(0).getAsJsonObject().get("text").getAsString();
                }
            }
            return null;
        } else {
            String url = PipConfig.getBaseUrl().isBlank()
                ? "https://api.openai.com/v1/chat/completions"
                : PipConfig.getBaseUrl();

            JsonArray messages = new JsonArray();
            JsonObject sysMsg = new JsonObject();
            sysMsg.addProperty("role", "system");
            sysMsg.addProperty("content", sysPrompt);
            messages.add(sysMsg);

            JsonObject usrMsg = new JsonObject();
            usrMsg.addProperty("role", "user");
            usrMsg.addProperty("content", playerName + ": " + message);
            messages.add(usrMsg);

            JsonObject payload = new JsonObject();
            payload.addProperty("model", model);
            payload.add("messages", messages);
            payload.addProperty("max_tokens", PipConfig.getMaxTokens());

            HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(18))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + apiKey)
                .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(payload)))
                .build();

            HttpResponse<String> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() >= 400) {
                throw new IllegalStateException(describeHttpError(resp.statusCode(), resp.body()));
            }
            JsonObject json = JsonParser.parseString(resp.body()).getAsJsonObject();
            JsonArray choices = json.getAsJsonArray("choices");
            if (choices != null && choices.size() > 0) {
                return choices.get(0).getAsJsonObject().getAsJsonObject("message").get("content").getAsString();
            }
            return null;
        }
    }

    private static String describeHttpError(int status, String body) {
        String hint = switch (status) {
            case 400 -> "bad request (check the model name / API key)";
            case 401, 403 -> "the API key was rejected";
            case 404 -> "model or URL not found (check the model name)";
            case 429 -> "rate limit / quota reached";
            default -> "server error";
        };
        String snippet = body == null ? "" : body.replaceAll("\\s+", " ");
        if (snippet.length() > 140) {
            snippet = snippet.substring(0, 140) + "...";
        }
        return "HTTP " + status + " - " + hint + (snippet.isEmpty() ? "" : " [" + snippet + "]");
    }

    /** Used by the /pip gui "Save & Test" button. Blocking - call from a worker thread. Returns a short status line. */
    public static String runConnectionTest() {
        PipConfig.ensureLoaded();
        String apiKey = PipConfig.getApiKey();
        if (apiKey.isBlank()) {
            return "§cNo API key saved yet.";
        }
        try {
            String reply = callConfiguredApi(apiKey, "connection test", "Tester", "Say hi in five words or fewer.");
            if (reply == null || reply.isBlank()) {
                return "§eConnected, but the model returned an empty reply. Try another model name.";
            }
            String clean = ACTION_TAG.matcher(reply).replaceAll("").trim();
            return "§aWorks! Pip says: " + (clean.length() > 80 ? clean.substring(0, 80) + "..." : clean);
        } catch (Exception ex) {
            return "§cFailed: " + ex.getMessage();
        }
    }

    private static void handleAiResponse(ServerLevel level, ServerPlayer player, PipChatListener pip, String userMessage, String rawReply) {
        String actionType = null;
        String actionArg = null;
        Matcher m = ACTION_TAG.matcher(rawReply);
        if (m.find()) {
            actionType = m.group(1);
            actionArg = m.group(2) != null ? m.group(2).trim() : "";
        }
        String visibleText = ACTION_TAG.matcher(rawReply).replaceAll("").trim();

        MEMORY.addLast("Owner: " + userMessage);
        MEMORY.addLast("Pip: " + visibleText);
        while (MEMORY.size() > 10) {
            MEMORY.removeFirst();
        }

        String prefix = pip.isFakePip() ? "§4[???] §c" : "§a[Pip] §f";
        if (!visibleText.isBlank()) {
            player.sendSystemMessage(Component.literal(prefix + visibleText));
            pip.playTalkVoice();
        }

        if (actionType != null && !pip.isFakePip()) {
            switch (actionType) {
                case "GATHER_WOOD" -> pip.startGatherWoodTask(player);
                case "FETCH" -> {
                    Item item = PipEventDirector.resolveItemByName(actionArg);
                    if (item != Items.AIR) {
                        pip.startFetchItemTask(player, item, item.getMaxStackSize() > 1 ? 8 : 1);
                    }
                }
                case "KILL", "HUNT" -> pip.startHuntByQuery(player, actionArg);
                case "STALK_PEEK", "STALK" -> pip.startStalkPeekTask(player, false);
                case "FOLLOW" -> pip.returnToFollowOwner(player);
            }
        }
    }

    private static String buildWorldContext(ServerLevel level, ServerPlayer player, PipChatListener pip) {
        String nearbyMobs = level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(24.0D), e -> e != pip && e != player)
            .stream()
            .limit(6)
            .map(e -> BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getPath() + "(" + Math.round(e.distanceTo(player)) + "m)")
            .collect(Collectors.joining(", "));
        boolean isNight = level.isNight();
        return String.format(
            Locale.ROOT,
            "form=%s, dist=%.1fm, health=%.0f/%.0f, night=%s, nearbyMobs=[%s]",
            pip.isFakePip() ? "JERRY_EYES_FAKE_PIP" : "FRIENDLY_PIP",
            pip.distanceTo(player),
            pip.getHealth(),
            pip.getMaxHealth(),
            isNight,
            nearbyMobs.isEmpty() ? "none" : nearbyMobs
        );
    }

    private static String buildSmartOfflineReply(ServerPlayer player, PipChatListener pip, String message) {
        String lower = message.toLowerCase(Locale.ROOT);
        if (pip.isFakePip()) {
            return "§4[???] §c...i can see you, " + player.getName().getString() + "...";
        }
        if (lower.contains("good") || lower.contains("cute") || lower.contains("pet")) {
            return "§a[Pip] §f*purrs happily and stays right behind your shoulder!*";
        }
        if (lower.contains("who") || lower.contains("what are you")) {
            return "§a[Pip] §fI'm Pip! I follow you everywhere, hide behind trees to watch, fetch items, gather wood, or hunt anything you tell me to kill.";
        }
        return "§a[Pip] §7*twitches ear beside you* (Tell me §e\"pip, gather wood\"§7, §e\"pip, fetch diamond\"§7, or §e\"pip, kill a zombie\"§7!)";
    }
}
