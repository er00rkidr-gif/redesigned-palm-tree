package com.piphorror.mod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.piphorror.mod.ai.PipEventDirector;
import com.piphorror.mod.entity.PipChatListener;
import com.piphorror.mod.net.PipNetwork;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Comparator;
import java.util.List;

@Mod.EventBusSubscriber(modid = "piphorror", bus = Mod.EventBusSubscriber.Bus.FORGE)
public class PipEventsCommand {
    private static final List<String> EVENT_KEYS = List.of("lights_flicker", "stalk_behind", "door_knock", "mimic_whisper", "hunt_escalation", "hallucination_decoy");
    private static final List<String> STATE_KEYS = List.of(
        PipChatListener.STATE_STALK,
        PipChatListener.STATE_LOOKOUT_LISTEN,
        PipChatListener.STATE_PROWL_WALK,
        PipChatListener.STATE_PEEK,
        PipChatListener.STATE_HUNT,
        PipChatListener.STATE_FAKE_IGNORE,
        PipChatListener.STATE_SUMMON
    );
    private static final java.util.function.Predicate<CommandSourceStack> OP = src -> src.hasPermission(2);
    private static final List<String> VARIANT_KEYS = List.of("real", "fake");

    private static final SuggestionProvider<CommandSourceStack> EVENT_SUGGESTIONS =
        (ctx, builder) -> SharedSuggestionProvider.suggest(EVENT_KEYS, builder);
    private static final SuggestionProvider<CommandSourceStack> STATE_SUGGESTIONS =
        (ctx, builder) -> SharedSuggestionProvider.suggest(STATE_KEYS, builder);
    private static final SuggestionProvider<CommandSourceStack> VARIANT_SUGGESTIONS =
        (ctx, builder) -> SharedSuggestionProvider.suggest(VARIANT_KEYS, builder);

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();

        dispatcher.register(Commands.literal("pip")
            // Every subcommand below needs op (permission 2) except "gui", which the singleplayer owner may also use.
            .then(Commands.literal("gui")
                .requires(PipEventsCommand::canUseGui)
                .executes(ctx -> openGui(ctx.getSource())))
            .then(Commands.literal("sleep").requires(OP)
                .executes(ctx -> triggerSleep(ctx.getSource())))
            .then(Commands.literal("listen").requires(OP)
                .executes(ctx -> triggerListen(ctx.getSource(), ctx.getSource().getPlayerOrException()))
                .then(Commands.argument("target", EntityArgument.player())
                    .executes(ctx -> triggerListen(ctx.getSource(), EntityArgument.getPlayer(ctx, "target")))))
            .then(Commands.literal("follow").requires(OP)
                .executes(ctx -> triggerFollow(ctx.getSource())))
            .then(Commands.literal("stalk").requires(OP)
                .executes(ctx -> triggerStalk(ctx.getSource())))
            .then(Commands.literal("kill").requires(OP)
                .then(Commands.argument("target_name", StringArgumentType.greedyString())
                    .executes(ctx -> triggerKill(ctx.getSource(), StringArgumentType.getString(ctx, "target_name")))))
            .then(Commands.literal("gather").requires(OP)
                .then(Commands.literal("wood")
                    .executes(ctx -> triggerGatherWood(ctx.getSource()))))
            .then(Commands.literal("fetch").requires(OP)
                .then(Commands.argument("item_name", StringArgumentType.greedyString())
                    .executes(ctx -> triggerFetch(ctx.getSource(), StringArgumentType.getString(ctx, "item_name")))))
            .then(Commands.literal("event").requires(OP)
                .then(Commands.argument("event_id", StringArgumentType.word())
                    .suggests(EVENT_SUGGESTIONS)
                    .executes(ctx -> triggerEvent(
                        ctx.getSource(),
                        StringArgumentType.getString(ctx, "event_id"),
                        ctx.getSource().getPlayerOrException()
                    ))
                    .then(Commands.argument("target", EntityArgument.player())
                        .executes(ctx -> triggerEvent(
                            ctx.getSource(),
                            StringArgumentType.getString(ctx, "event_id"),
                            EntityArgument.getPlayer(ctx, "target")
                        )))))
            .then(Commands.literal("state").requires(OP)
                .then(Commands.argument("ai_state", StringArgumentType.word())
                    .suggests(STATE_SUGGESTIONS)
                    .executes(ctx -> setState(ctx.getSource(), StringArgumentType.getString(ctx, "ai_state")))))
            .then(Commands.literal("variant").requires(OP)
                .then(Commands.argument("kind", StringArgumentType.word())
                    .suggests(VARIANT_SUGGESTIONS)
                    .executes(ctx -> setVariant(ctx.getSource(), StringArgumentType.getString(ctx, "kind")))))
        );
    }

    private static boolean canUseGui(CommandSourceStack src) {
        if (src.hasPermission(2)) {
            return true;
        }
        ServerPlayer player = src.getPlayer();
        return player != null && src.getServer().isSingleplayerOwner(player.getGameProfile());
    }

    private static int openGui(CommandSourceStack source) {
        ServerPlayer player = source.getPlayer();
        if (player == null) {
            source.sendFailure(Component.literal("/pip gui must be run by a player."));
            return 0;
        }
        PipNetwork.sendOpenGui(player);
        return 1;
    }

    private static int triggerSleep(CommandSourceStack source) {
        ServerPlayer player = source.getPlayer();
        if (player == null) return 0;
        PipChatListener pip = findNearestPip(source.getLevel(), player);
        if (pip == null) {
            source.sendFailure(Component.literal("No Pip entity found nearby."));
            return 0;
        }
        pip.setDormant(true);
        source.sendSuccess(() -> Component.literal("Pip is now a motionless Unknown Corpse. Feed it a Bucket of Axolotl!"), true);
        return 1;
    }

    private static int triggerFollow(CommandSourceStack source) {
        ServerPlayer player = source.getPlayer();
        if (player == null) return 0;
        PipChatListener pip = findNearestPip(source.getLevel(), player);
        if (pip == null) {
            source.sendFailure(Component.literal("No Pip entity found nearby."));
            return 0;
        }
        pip.returnToFollowOwner(player);
        return 1;
    }

    private static int triggerStalk(CommandSourceStack source) {
        ServerPlayer player = source.getPlayer();
        if (player == null) return 0;
        PipChatListener pip = findNearestPip(source.getLevel(), player);
        if (pip == null) {
            source.sendFailure(Component.literal("No Pip entity found nearby."));
            return 0;
        }
        pip.startStalkPeekTask(player, false);
        source.sendSuccess(() -> Component.literal("Pip is stalking behind the nearest tree/block cover!"), true);
        return 1;
    }

    private static int triggerKill(CommandSourceStack source, String targetName) {
        ServerPlayer player = source.getPlayer();
        if (player == null) return 0;
        PipChatListener pip = findNearestPip(source.getLevel(), player);
        if (pip == null) {
            source.sendFailure(Component.literal("No Pip entity found nearby."));
            return 0;
        }
        return pip.startHuntByQuery(player, targetName) ? 1 : 0;
    }

    private static int triggerListen(CommandSourceStack source, ServerPlayer target) {
        ServerLevel level = source.getLevel();
        PipChatListener pip = findNearestPip(level, target);
        if (pip == null) {
            source.sendFailure(Component.literal("No Pip entity found within 96 blocks."));
            return 0;
        }
        boolean listened = pip.startLookoutListen(target, 120);
        if (!listened) {
            source.sendSuccess(() -> Component.literal("Nearest Pip has Jerry eyes and only stares back at you!"), true);
            return 1;
        }
        source.sendSuccess(() -> Component.literal("Original Pip entered Lookout listen pose for " + target.getName().getString()), true);
        return 1;
    }

    private static int triggerGatherWood(CommandSourceStack source) {
        ServerPlayer player = source.getPlayer();
        if (player == null) return 0;
        PipChatListener pip = findNearestPip(source.getLevel(), player);
        if (pip == null) {
            source.sendFailure(Component.literal("No Pip entity found nearby."));
            return 0;
        }
        pip.startGatherWoodTask(player);
        return 1;
    }

    private static int triggerFetch(CommandSourceStack source, String itemName) {
        ServerPlayer player = source.getPlayer();
        if (player == null) return 0;
        PipChatListener pip = findNearestPip(source.getLevel(), player);
        if (pip == null) {
            source.sendFailure(Component.literal("No Pip entity found nearby."));
            return 0;
        }
        Item resolved = PipEventDirector.resolveItemByName(itemName);
        if (resolved == Items.AIR) {
            source.sendFailure(Component.literal("Unknown Minecraft item: " + itemName));
            return 0;
        }
        int count = resolved.getMaxStackSize() > 1 ? 8 : 1;
        pip.startFetchItemTask(player, resolved, count);
        return 1;
    }

    private static int triggerEvent(CommandSourceStack source, String eventId, ServerPlayer target) {
        ServerLevel level = source.getLevel();
        PipChatListener pip = findNearestPip(level, target);
        if (pip == null) {
            source.sendFailure(Component.literal("No Pip entity found within 96 blocks."));
            return 0;
        }
        boolean ok = PipEventDirector.executeEvent(level, target, pip, eventId);
        if (!ok) {
            source.sendFailure(Component.literal("Unknown Pip event: " + eventId));
            return 0;
        }
        source.sendSuccess(() -> Component.literal("Executed Pip event: " + eventId), true);
        return 1;
    }

    private static int setState(CommandSourceStack source, String aiState) {
        ServerPlayer player = source.getPlayer();
        if (player == null) return 0;
        PipChatListener pip = findNearestPip(source.getLevel(), player);
        if (pip == null) {
            source.sendFailure(Component.literal("No Pip entity found nearby."));
            return 0;
        }
        pip.triggerTimedState(aiState, 160);
        source.sendSuccess(() -> Component.literal("Set Pip animation/AI state to " + aiState), true);
        return 1;
    }

    private static int setVariant(CommandSourceStack source, String kind) {
        ServerPlayer player = source.getPlayer();
        if (player == null) return 0;
        PipChatListener pip = findNearestPip(source.getLevel(), player);
        if (pip == null) {
            source.sendFailure(Component.literal("No Pip entity found nearby."));
            return 0;
        }
        boolean fake = "fake".equalsIgnoreCase(kind);
        pip.setFakePip(fake);
        source.sendSuccess(() -> Component.literal("Set nearest Pip variant to " + (fake ? "JERRY EYES (stares, won't listen)" : "FRIENDLY PIP")), true);
        return 1;
    }

    private static PipChatListener findNearestPip(ServerLevel level, ServerPlayer player) {
        return level.getEntitiesOfClass(PipChatListener.class, player.getBoundingBox().inflate(96.0D))
            .stream()
            .min(Comparator.comparingDouble(p -> p.distanceToSqr(player)))
            .orElse(null);
    }
}
