package com.piphorror.mod.client.gui;

import com.piphorror.mod.net.PipNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.util.FormattedCharSequence;

/** The /pip gui screen: set up Pip's AI brain (Gemini or OpenAI-compatible) without editing files. */
public class PipSetupScreen extends Screen {
    private static final String[] PROVIDERS = {"gemini", "openai"};

    private boolean enabled;
    private String provider;
    private final String initialModel;
    private final String initialUrl;
    private final boolean hasSavedKey;

    private EditBox keyBox;
    private EditBox modelBox;
    private EditBox urlBox;
    private Button providerButton;
    private Button enabledButton;
    private Button showButton;
    private boolean showKey = false;
    private Component status = Component.empty();

    public PipSetupScreen(boolean enabled, String provider, String model, String baseUrl, boolean hasSavedKey) {
        super(Component.translatable("piphorror.gui.title"));
        this.enabled = enabled;
        this.provider = provider.toLowerCase().contains("openai") ? "openai" : "gemini";
        this.initialModel = model;
        this.initialUrl = baseUrl;
        this.hasSavedKey = hasSavedKey;
    }

    // Called by the network packets (client side only)
    public static void open(boolean enabled, String provider, String model, String baseUrl, boolean hasKey) {
        Minecraft.getInstance().setScreen(new PipSetupScreen(enabled, provider, model, baseUrl, hasKey));
    }

    public static void showStatus(String legacyText) {
        if (Minecraft.getInstance().screen instanceof PipSetupScreen screen) {
            screen.status = Component.literal(legacyText);
        }
    }

    private static String defaultModel(String provider) {
        return "openai".equals(provider) ? "gpt-4o-mini" : "gemini-2.5-flash";
    }

    @Override
    protected void init() {
        int w = Math.min(260, this.width - 20);
        int x = this.width / 2 - w / 2;
        int y = Math.max(34, this.height / 2 - 98);
        int row = 36;

        // Row 1: provider + enable toggle
        this.providerButton = Button.builder(providerLabel(), b -> {
            String oldDefault = defaultModel(provider);
            provider = "gemini".equals(provider) ? "openai" : "gemini";
            if (modelBox.getValue().isBlank() || modelBox.getValue().equals(oldDefault)) {
                modelBox.setValue(defaultModel(provider));
            }
            b.setMessage(providerLabel());
        }).bounds(x, y, w / 2 - 2, 20).build();
        this.enabledButton = Button.builder(enabledLabel(), b -> {
            enabled = !enabled;
            b.setMessage(enabledLabel());
        }).bounds(x + w / 2 + 2, y, w / 2 - 2, 20).build();
        addRenderableWidget(providerButton);
        addRenderableWidget(enabledButton);

        // Row 2: API key (masked) + show/hide
        int keyW = w - 52;
        this.keyBox = new EditBox(this.font, x, y + row + 12, keyW, 20, Component.translatable("piphorror.gui.api_key"));
        this.keyBox.setMaxLength(400);
        this.keyBox.setHint(Component.literal(hasSavedKey ? "(saved - leave empty to keep)" : "paste your key here"));
        this.keyBox.setFormatter((text, offset) -> showKey
            ? FormattedCharSequence.forward(text, Style.EMPTY)
            : FormattedCharSequence.forward("*".repeat(text.length()), Style.EMPTY));
        addRenderableWidget(keyBox);
        this.showButton = Button.builder(Component.translatable("piphorror.gui.show"), b -> {
            showKey = !showKey;
            b.setMessage(Component.translatable(showKey ? "piphorror.gui.hide" : "piphorror.gui.show"));
        }).bounds(x + keyW + 2, y + row + 12, 50, 20).build();
        addRenderableWidget(showButton);

        // Row 3: model
        this.modelBox = new EditBox(this.font, x, y + row * 2 + 12, w, 20, Component.translatable("piphorror.gui.model"));
        this.modelBox.setMaxLength(100);
        this.modelBox.setValue(initialModel.isBlank() ? defaultModel(provider) : initialModel);
        addRenderableWidget(modelBox);

        // Row 4: custom URL
        this.urlBox = new EditBox(this.font, x, y + row * 3 + 12, w, 20, Component.translatable("piphorror.gui.base_url"));
        this.urlBox.setMaxLength(400);
        this.urlBox.setValue(initialUrl);
        addRenderableWidget(urlBox);

        // Buttons
        int by = y + row * 4 + 18;
        addRenderableWidget(Button.builder(Component.translatable("piphorror.gui.test"), b -> save(true))
            .bounds(x, by, w / 2 - 2, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("piphorror.gui.save"), b -> save(false))
            .bounds(x + w / 2 + 2, by, w / 2 - 2, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("piphorror.gui.done"), b -> onClose())
            .bounds(x, by + 24, w, 20).build());
    }

    private Component providerLabel() {
        return Component.literal("Provider: " + ("openai".equals(provider) ? "OpenAI-compatible" : "Gemini"));
    }

    private Component enabledLabel() {
        return Component.literal("AI chat: " + (enabled ? "§aON" : "§cOFF"));
    }

    private void save(boolean test) {
        status = Component.literal("§7Saving...");
        PipNetwork.sendSave(enabled, provider, keyBox.getValue(), modelBox.getValue(), urlBox.getValue(), test);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);
        g.drawCenteredString(this.font, this.title, this.width / 2, 12, 0xFFFFFF);
        int w = Math.min(260, this.width - 20);
        int x = this.width / 2 - w / 2;
        int y = Math.max(34, this.height / 2 - 98);
        int row = 36;
        g.drawString(this.font, Component.translatable("piphorror.gui.api_key"), x, y + row + 1, 0xA0A0A0);
        g.drawString(this.font, Component.translatable("piphorror.gui.model"), x, y + row * 2 + 1, 0xA0A0A0);
        g.drawString(this.font, Component.translatable("piphorror.gui.base_url"), x, y + row * 3 + 1, 0xA0A0A0);
        g.drawCenteredString(this.font, status, this.width / 2, y + row * 4 + 66, 0xFFFFFF);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
