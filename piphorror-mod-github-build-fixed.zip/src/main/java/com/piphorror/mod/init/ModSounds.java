package com.piphorror.mod.init;

import com.piphorror.mod.PipHorrorMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
        DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, PipHorrorMod.MOD_ID);

    /** "Hey, I am Pip, thanks for feeding me that!" */
    public static final RegistryObject<SoundEvent> PIP_HEY = register("pip.hey");
    /** Short chirpy babble (3 variants). */
    public static final RegistryObject<SoundEvent> PIP_TALK = register("pip.talk");

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(PipHorrorMod.MOD_ID, name)));
    }
}
